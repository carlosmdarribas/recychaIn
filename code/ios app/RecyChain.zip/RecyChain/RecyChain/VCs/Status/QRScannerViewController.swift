//
//  QRScannerViewController.swift
//  RecyChain
//
//  Created by Carlos on 18/11/2020.
//

import UIKit
import AVFoundation
import CodeScanner
import SwiftKeychainWrapper
import MBProgressHUD

class QRScannerViewController: UIViewController {
    private var scanner: CodeScanner!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.scanner = CodeScanner(metadataObjectTypes: [AVMetadataObject.ObjectType.qr], preview: self.view)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        CodeScanner.requestCameraPermission { (success) in
            if success {
                self.scanner.scan(resultOutputs: { (outputs) in
                    print(outputs)
                    
                    // El código QR que genera la máquina debe ser del tipo:
                    // container_id|trash_type|weight|hash
                    
                    let elements = outputs.split(separator: "|")
                    guard elements.count == 4 else {
                        print("QR no válido")
                        return
                    }
                    let container_id = elements[0], trash = elements[1], weight = elements[2]
                    let address = KeychainWrapper.standard.string(forKey: "bcAddress") ?? ""
                    
                    BlockchainUtils.measureAndPay(address: address, containerId: "\(container_id)", trashType: "\(trash)", weight: Double("\(weight)") ?? 0.0)
                    
                    let hud = MBProgressHUD.showAdded(to: self.view, animated: true)
                    hud.mode = .text
                    hud.label.text = "Enviado correctamente"
                    hud.detailsLabel.text = "Se le notificará cuando se abone"
                    
                    hud.hide(animated: true, afterDelay: 3.0)
                })
            }
        }
    }
}
