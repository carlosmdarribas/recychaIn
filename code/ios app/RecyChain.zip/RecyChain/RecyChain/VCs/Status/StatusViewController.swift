//
//  StatusViewController.swift
//  RecyChain
//
//  Created by Carlos on 17/11/2020.
//

import UIKit
import Charts
import SwiftKeychainWrapper

class StatusViewController: UIViewController {
    @IBOutlet weak var chartsView: PieChartView!
    
    @IBOutlet weak var emotionEmoji: UILabel!
    
    @IBOutlet weak var walletQRImage: UIImageView!
    @IBOutlet weak var walletLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.generatePlot()
        
        self.getTwitterEmotions()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.checkFirstAccess()
    }
    
    func checkFirstAccess() {
        // TODO: poner en algún lado mejor.
        
        if !UserDefaults.standard.bool(forKey: "launchedBefore") {
            self.walletLabel.text = "Creando cuenta..."
                        
            BlockchainUtils.createWallet { (address) in
                // Por seguridad se guarda en el keychain cifrado de iOS.
                KeychainWrapper.standard.set(address.address, forKey: "bcAddress")
                KeychainWrapper.standard.set(address.keys, forKey: "bcPrivKey")
                
                self.walletQRImage.image = QRGenerator.generateQRCode(from: address.address)
                BlockchainUtils.getWalletBalanceAPI(address: address.address) { (balance) in
                    self.walletLabel.text = "\(balance) Tokens"
                } errorHandler: { (error) in
                    print(error)
                }

                
                UserDefaults.standard.set(true, forKey: "launchedBefore")
            } errorHandler: { (error) in
                print("Error "+error)
            }
        } else {
            let address = KeychainWrapper.standard.string(forKey: "bcAddress") ?? ""
            self.walletQRImage.image = QRGenerator.generateQRCode(from: address)
            
            BlockchainUtils.getWalletBalanceAPI(address: address) { (balance) in
                print("balance: " + balance)
                self.walletLabel.text = "\(balance) Tokens"
            } errorHandler: { (error) in
                print(error)
            }
        }
        
    }
    
    func getTwitterEmotions() {
        WebRequests.getTwitterEmotion { (sentimentType) in
            switch sentimentType {
            case SentimentType.str_negative: self.emotionEmoji.text = "🤬"
            case SentimentType.negative: self.emotionEmoji.text = "😡"
            case SentimentType.weakNegative: self.emotionEmoji.text = "😟"
            case SentimentType.neutral: self.emotionEmoji.text = "😐"
            case SentimentType.weakPos: self.emotionEmoji.text = "🤗"
            case SentimentType.positive: self.emotionEmoji.text = "😁"
            case SentimentType.strPositive: self.emotionEmoji.text = "🤪"
            case SentimentType.unknown: self.emotionEmoji.text = "❓"
            }
        } errorHandler: { (error) in
            print(error)
        }
        
    }
    
    func getWalletBalance() {
        BlockchainUtils.getWalletBalanceAPI(address: KeychainWrapper.standard.string(forKey: "bcAddress") ?? "") { (address) in
            self.walletLabel.text = address
        } errorHandler: { (error) in
            print("Error creando cuenta")
        }

    }
    
    func generatePlot() {
        guard let chartView = self.chartsView else {
            return
        }
        
        chartView.delegate = self
        
        chartView.holeColor = .white
        chartView.transparentCircleColor = NSUIColor.white.withAlphaComponent(0.43)
        chartView.holeRadiusPercent = 0.58
        chartView.rotationEnabled = false
        chartView.highlightPerTapEnabled = true
        
        chartView.maxAngle = 180 // Half chart
        chartView.rotationAngle = 180 // Rotate to make the half on the upper side
        chartView.centerTextOffset = CGPoint(x: 0, y: -20)
        
        let l = chartView.legend
        l.horizontalAlignment = .center
        l.verticalAlignment = .top
        l.orientation = .horizontal
        l.drawInside = false
        l.xEntrySpace = 7
        l.yEntrySpace = 0
        l.yOffset = 0
        //        chartView.legend = l
        
        // entry label styling
        chartView.entryLabelColor = .white
        chartView.entryLabelFont = UIFont(name:"HelveticaNeue-Light", size:12)!
        
        self.updateChartData()
        
        chartView.animate(xAxisDuration: 1.4, easingOption: .easeOutBack)
    }
    
    func updateChartData() {
        let doneRecys = 60.0
        let entries = [PieChartDataEntry(value: doneRecys), PieChartDataEntry(value: 100-doneRecys)]
        
        let set = PieChartDataSet(entries: entries, label: "Elementos Reciclados de la meta")
        set.sliceSpace = 3
        set.selectionShift = 5
        set.colors = ChartColorTemplates.material()
        
        let data = PieChartData(dataSet: set)
        
        let pFormatter = NumberFormatter()
        pFormatter.numberStyle = .percent
        pFormatter.maximumFractionDigits = 1
        pFormatter.multiplier = 1
        pFormatter.percentSymbol = " %"
        data.setValueFormatter(DefaultValueFormatter(formatter: pFormatter))
        
        data.setValueFont(UIFont(name: "HelveticaNeue-Light", size: 11)!)
        data.setValueTextColor(.white)
        
        chartsView.data = data
        
        chartsView.setNeedsDisplay()
    }
}

extension StatusViewController: ChartViewDelegate {
    
}

