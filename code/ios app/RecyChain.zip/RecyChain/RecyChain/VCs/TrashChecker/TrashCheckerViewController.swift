//
//  TrashCheckerViewController.swift
//  RecyChain
//
//  Created by Carlos on 18/11/2020.
//

import UIKit
import AVFoundation
import MBProgressHUD

class TrashCheckerViewController: UIViewController {
    @IBOutlet weak var resultStackView: UIStackView! //TODO: Arreglar. Chapuza. Hacer una clase aparte que sea este elemento.
    @IBOutlet weak var cameraButton: UIButton!
    @IBOutlet weak var resultImage: UIImageView!
    @IBOutlet weak var resultLabl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.resultStackView.alpha = 0
        self.configureInterfaces()
    }
    
    func configureInterfaces() {
        self.cameraButton.clipsToBounds = true
        self.cameraButton.layer.cornerRadius = self.cameraButton.frame.width / 2
    }
    
    @IBAction func takePicture(_ sender: Any) {
        let vc = UIImagePickerController()
        vc.sourceType = .camera
        vc.allowsEditing = true
        vc.delegate = self
        present(vc, animated: true)
    }
}

extension TrashCheckerViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
        
        guard let image = info[.editedImage] as? UIImage else {
               print("No image found")
               return
           }
        
        self.resultLabl.text = "Cargando..."
        
        var hud = MBProgressHUD.showAdded(to: self.view, animated: true)
        hud.mode = .indeterminate
        hud.label.text = "Cargando..."

        UIView.animate(withDuration: 1.0) {
            self.resultStackView.alpha = 1.0
        }
        self.resultImage.image = image
        
        // Consulta a API
        guard let imagedata = image.jpegData(compressionQuality: 0.2) else {
            print("Imagen inválida")
            hud.hide(animated: true)
            
            self.resultLabl.text = "ERROR"
            return
        }
        
        WebRequests.getImageClassification(image: imagedata.base64EncodedString()) { (container) in
            hud.hide(animated: true)
            
            hud = MBProgressHUD.showAdded(to: self.view, animated: true)
            hud.label.text = "Resultado"
            hud.detailsLabel.text = "Debe ir con \(container)"
            hud.hide(animated: true, afterDelay: 3.0)
        }
    }
}
