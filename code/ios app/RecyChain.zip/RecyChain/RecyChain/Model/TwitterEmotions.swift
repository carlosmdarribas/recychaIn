//
//  TwitterEmotions.swift
//  RecyChain
//
//  Created by Carlos on 18/11/2020.
//

import Foundation

class Sentiment: Codable {
    var sentiment: [EachSentiment]
}

class EachSentiment: Codable {
    let sentiment: Double
    let type: SentimentType

    init(sentiment: Double, type: SentimentType) {
        self.sentiment = sentiment
        self.type = type
    }
}

enum SentimentType: String, Codable {
    case str_negative = "strong negative"
    case negative = "negative"
    case weakNegative = "weak negative"
    case neutral = "neutral"
    case weakPos = "weak positive"
    case positive = "positive"
    case strPositive = "strong positive"
    case unknown = "unknown"
}
