//
//  BlockchainAddress.swift
//  RecyChain
//
//  Created by Carlos on 17/11/2020.
//

import Foundation

class BlockchainAddress {
    let address: String
    let keys: Data
    
    init(address: String, keys: Data) {
        self.address = address
        self.keys = keys
    }
}
