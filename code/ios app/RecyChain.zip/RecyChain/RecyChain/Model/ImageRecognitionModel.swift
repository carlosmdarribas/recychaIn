//
//  ImageRecognitionModel.swift
//  RecyChain
//
//  Created by Carlos on 18/11/2020.
//

import Foundation

// MARK: - Welcome
struct ImageRecognited: Codable {
    let images: [Image]
    let imagesProcessed, customClasses: Int

    enum CodingKeys: String, CodingKey {
        case images
        case imagesProcessed = "images_processed"
        case customClasses = "custom_classes"
    }
}

// MARK: - Image
struct Image: Codable {
    let classifiers: [Classifier]
    let image: String
}

// MARK: - Classifier
struct Classifier: Codable {
    let classifierID, name: String
    let classes: [Class]

    enum CodingKeys: String, CodingKey {
        case classifierID = "classifier_id"
        case name, classes
    }
}

// MARK: - Class
struct Class: Codable {
    let classClass: String
    let score: Double

    enum CodingKeys: String, CodingKey {
        case classClass = "class"
        case score
    }
}
