//
//  BlockchainUtils.swift
//  RecyChain
//
//  Created by Carlos on 17/11/2020.
//

import Foundation
import web3swift
import SwiftKeychainWrapper
import BigInt
import Alamofire

class BlockchainUtils {
    fileprivate static let contractAddress = EthereumAddress("")
    fileprivate static let contractABI = ""
    fileprivate static var web3 = Web3.InfuraMainnetWeb3()
    
    /// Creates a new wallet on the ethereum blockchain network.
    /// - Parameters:
    ///   - completionHandler: Lambda, called when everythings gets ok. Returns BlockchainAddress class.
    ///   - errorHandler: Lambda, return error string. // TODO: Cambiar por modelo de error.
    /// - Returns: 
    public static func createWallet(completionHandler:@escaping (_ ethAdd: BlockchainAddress) -> (), errorHandler:@escaping (_ error: String) -> ()) {
        do {
            let password = Utils.generatePassword(length: 10)
            guard let keystore = try EthereumKeystoreV3(password: password),
                  let addresses = keystore.addresses, 
                  addresses.count > 0 else {
                print("Keystore inválida o addresses insuficientes")
                return
            }
                
            let keyData = try JSONEncoder().encode(keystore.keystoreParams)
            
            activateWallet(address: addresses[0].address) { (success) in
                print("OK")
            } errorHandler: { (error) in
                print("Error")
            }

            completionHandler(BlockchainAddress(address: addresses[0].address, keys: keyData))
        } catch {
            print("Error: \(error.localizedDescription)")
            errorHandler("Error creating wallet")
        }
    }
    
    /// Gets the given address' balance.
    /// - Parameters:
    ///   - walletAddress: wallet which address wants to be got
    ///   - completionHandler:  Lambda, called when everythings gets ok. Returns balance.
    ///   - errorHandler: Lambda, return error string. // TODO: Cambiar por modelo de error.
    /// - Returns:
    public static func getWalletBalance(walletAddress: String, completionHandler:@escaping (_ balance: String) -> (), errorHandler:@escaping (_ error: String) -> ()) {
        let (contract, options) = BlockchainUtils.getContract(walletAddress: walletAddress)
        
        let method = "balanceOf"
        let tx = contract.read(
            method,
            parameters: [walletAddress] as [AnyObject],
            extraData: Data(),
            transactionOptions: options)!
        
        do {
            let tokenBalance = try tx.call()
        
            let balanceBigUInt = tokenBalance["0"] as! BigUInt
            guard let balanceString = Web3.Utils.formatToEthereumUnits(balanceBigUInt, toUnits: .eth, decimals: 3) else {
                completionHandler("Error parsing balance")
                return
            }

            completionHandler(balanceString)
            
        } catch {
            completionHandler("Error calling balance")
            return
        }
    }
    
    public static func getWalletBalanceAPI(address: String, completionHandler:@escaping (_ balance: String) -> (), errorHandler:@escaping (_ error: String) -> ()) {
        let url = "https://eu-gb.functions.appdomain.cloud/api/v1/web/franpintosantos%40usal.es_dev/default/get_balance" // TODO: PENDIENTE
        
        Alamofire.request(url, method: .post, parameters: ["address": address]).responseJSON { (response) in
            guard let response = response.result.value as? [String: Any] else {
                print("Error")
                errorHandler("Error parsing")
                return
            }
            
            guard let balance = response["balance"] as? String else {
                print("Error")
                errorHandler("Error parsing")
                return
            }
            
            completionHandler(balance)
        }
    }
    
    
    public static func measureAndPay(address: String, containerId: String, trashType: String, weight: Double) {
        let url = "http://t24h.es:50013/measure_and_pay"
        
        let parameters:Parameters = ["user_address": address, "container_address": containerId, "trash_type": trashType, "weight": weight]
        Alamofire.request(url, method: .post, parameters: parameters).response { (str) in
            // Será notificado cuando se registre la transacción.
            // No es necesarsia respuesta al usuario.l
        }
    }
    
    fileprivate static func activateWallet(address: String, completionHandler:@escaping (_ success: Bool) -> (), errorHandler:@escaping (_ error: String) -> ()) {
        let url = "http://t24h.es:50013/activate_wallet"
        
        Alamofire.request(url, method: .post, parameters: ["address": address]).response { (str) in
            completionHandler(str.response?.statusCode == 200 ? true : false)
        }
    }
    
    // Métodos privados.
    fileprivate static func getContract(walletAddress: String) -> (web3.web3contract, TransactionOptions) {
        let walletAddress = EthereumAddress(walletAddress)! // Your wallet address
        let contract = BlockchainUtils.web3.contract(Web3.Utils.erc20ABI, at: BlockchainUtils.contractAddress, abiVersion: 2)!
        var options = TransactionOptions.defaultOptions
        options.from = walletAddress
        options.gasPrice = .automatic
        options.gasLimit = .automatic
        
        return (contract, options)
    }
}
