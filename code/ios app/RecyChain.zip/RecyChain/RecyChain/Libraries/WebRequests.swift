//
//  WebRequests.swift
//  RecyChain
//
//  Created by Carlos on 17/11/2020.
//

import Foundation
import Alamofire

class WebRequests {
    
    fileprivate let serverIP = "t24h.es:50012"
    public static func getTwitterEmotion(completionHandler:@escaping (_ type: SentimentType) -> (), errorHandler:@escaping (_ error: String) -> ()) {
        let url = "https://eu-gb.functions.appdomain.cloud/api/v1/web/franpintosantos%40usal.es_dev/default/twitter-analysis-definitive"
        
        Alamofire.request(url, method: .get)
            /*.responseData { (data) in
            guard let tData = data.data else {
                errorHandler("Error parsing data")
                return
            }
            
            do {
                let sentiment = try JSONDecoder().decode(Sentiment.self, from: tData)
                completionHandler(sentiment.sentiment[0].type)
            } catch {
                print("error parsing: ", error)
                errorHandler("Error parsing data")
            }
        }*/
        .responseString { (str) in
            print(str)
            print(str.response?.statusCode)
        }
        .responseJSON { (response) in
            guard let response = response.result.value as? [String: Any] else {
                print("Error")
                return
            }
            
            guard let sentimentArray = response["sentiment"] as? [String: Any] else {
                print("Adios")
                return
            }
            
            guard let type = sentimentArray["type"] as? String, let typeParsed = SentimentType(rawValue: type) else {
                print("Error parseando sentimentArray")
                return
            }
            
            print(typeParsed)
            completionHandler(typeParsed)
        }
    }
    
    public static func getImageClassification(image: String, completionHandler:@escaping (_ type: String) -> ()) {
        let url = "http://t24h.es:50012/imageClassification"
        
        Alamofire.request(url, method: .post, parameters: ["img": image]).responseString { (response) in
            guard let response = response.result.value else {
                print("Error parsing response getImageClassification")
                return
            }
            
            print(response)
            if (response.contains("bottle") || response.contains("glass")) { completionHandler("cristal") }
            if (response.contains("cardboard") || response.contains("beige") || response.contains("ridge")) { completionHandler("cartón") }
            if (response.contains("beverage") || response.contains("plastic") || response.contains("bottled water")) { completionHandler("plastico") }
            if (response.contains("metal") || response.contains("iron") || response.contains("silver")) { completionHandler("metal") }
            if (response.contains("paper") || response.contains("silk")) { completionHandler("carton") }
            if (response.contains("trash") || response.contains("leave") || response.contains("maple") || response.contains("tree") || response.contains("plant")) { completionHandler("basura orgánica") }
        }.responseString { (str) in
            print(str)
        }
        /*
         .responseData { (data) in
         guard let tData = data.data else {
             errorHandler("Error parsing data")
             return
         }
         
         do {
             let sentiment = try JSONDecoder().decode(Sentiment.self, from: tData)
             completionHandler(sentiment.sentiment[0].type)
         } catch {
             print("error parsing: ", error)
             errorHandler("Error parsing data")
         }
     }
         */
    }
}
